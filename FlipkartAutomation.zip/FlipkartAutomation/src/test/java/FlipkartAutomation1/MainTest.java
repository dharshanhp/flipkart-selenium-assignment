package FlipkartAutomation1;

public class MainTest {
	
	 

	public static void main(String[] args) {
		// the main test cases are been running 
		
		BaseTest base = new BaseTest();
		
		base.Setup();
		
		// running of the test cases given to it searching one 
		
		try {
		 FlipkartHomePage homepage =new  FlipkartHomePage(base.driver);
		 
		 homepage.closingpopup();
		 
		 homepage.searchProducts("Bluetooth Speakers");
		 
		 
		 
		 // Search results actions
         SearchResultsPage searchPage = new SearchResultsPage(base.driver);
         searchPage.ApplyingBrandFilter("boAt");
         searchPage.applyCustomerRating("4★ & above");
         searchPage.sortByPriceLowToHigh();
         searchPage.openFirstProductInNewTab();
         
         // Product page actions
         ProductPage productPage = new ProductPage(base.driver);
         productPage.checkAvailableOffers();
         
         
         
         //cardSections to be added 
         
         CartPage card = new CartPage(base.driver);
         
         
         if(card.isAddToCartAvailable()) {
         
         card.addToCartAndGoToCart();
         }else {
        	 
        	 card.handleProductUnavailable();
         }
		 

		 
		}catch(Exception e) {
			e.printStackTrace();
			
			
			
		}finally {
			
			base.tearDown();
			
		}

	}

}
