package FlipkartAutomation1;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseTest {
	
	protected  WebDriver driver;
	
	public void Setup() {
		
		driver = new ChromeDriver();
		
		// for the max of the windows it is given as 
		
		driver.manage().window().maximize();
		
		//adding the  wait for the browser actions
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
		// opening the flipkart.com for the test actions 
		
		driver.get("https://www.flipkart.com/");
		
		
	}
	
	// for the application to be closing we can make use of the teardown
	
	public void tearDown() {
		
		if(driver!=null) {
			driver.quit();
			
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
