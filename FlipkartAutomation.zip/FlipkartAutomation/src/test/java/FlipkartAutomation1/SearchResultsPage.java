package FlipkartAutomation1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchResultsPage {
	private WebDriver driver;
	
	public SearchResultsPage(WebDriver driver) {
		
		this.driver =driver;
		
		
	}
	
	// applying the filter for the gievn brand 
	
	public void ApplyingBrandFilter(String brandName) {
		
		try {
			
			WebElement brandfilter =driver.findElement(By.xpath("//div[text()='Brand']"));
			
			brandfilter.click();
			
			
			
	WebElement brandfilte =driver.findElement(By.xpath("//div[text()='boAt']"));
			
			brandfilte.click();
			
			
			
		/*	 WebElement brandFilter = driver.findElement(By.xpath("//div[text()='" + brandName + "']/preceding-sibling::div"));
	            brandFilter.click();
	            System.out.println("Brand filter applied: " + brandName);
	            Thread.sleep(2000); // wait for page to reload
			
			*/
			
			
			
			
			
			
		}catch(Exception e) {
			
			e.printStackTrace();
			
			System.out.println("Brand filter not found"+brandName);
			
			
		}
		
	}
	
	// APPLYING FOR THE STAR GIVEN FOR IT 
	
	 public void applyCustomerRating(String rating) {
	        try {
	        	
	        	
	        	
	            WebElement ratingFilter = driver.findElement(By.xpath("//div[contains(text(),'" + rating + "')]/preceding-sibling::div"));
	            ratingFilter.click();
	            System.out.println("Customer rating filter applied: " + rating);
	            Thread.sleep(2000);
	        	
	        	
	        	
	        	
	    	/*	WebElement RATEfilter =driver.findElement(By.xpath("//div[text()='Customer Ratings']"));
	    		
	    		
	    		 JavascriptExecutor js = (JavascriptExecutor) driver;

				 js.executeScript("arguments[0].scrollIntoView({block:'center'})", RATEfilter);
				 js.executeScript("arguments[0].click()", RATEfilter);

				
				
				
				
		WebElement ratefilte =driver.findElement(By.xpath("//div[text()='4★ & above']"));
		
		
		
		 JavascriptExecutor js1 = (JavascriptExecutor) driver;

		 js1.executeScript("arguments[0].scrollIntoView({block:'center'})", ratefilte);
		 js1.executeScript("arguments[0].click()", ratefilte);

				
				ratefilte.click();
				
	        	
	        	*/
	        	
	        	
	        	
	        } catch (Exception e) {
	            System.out.println("Rating filter not found: " + rating);
	        }
	    }
	 
	  // Sort by Price → Low to High for the given website page
	    public void sortByPriceLowToHigh() {
	        try {
	            WebElement sortOption = driver.findElement(By.xpath("//div[contains(text(),'Price -- Low to High')]"));
	            sortOption.click();
	            System.out.println("Sorted by Price: Low to High");
	            Thread.sleep(2000);
	        } catch (Exception e) {
	            System.out.println("Sort option not found");
	        }
	    }
	    

	    // Open first product in new tab
	    public void openFirstProductInNewTab() {
	        try {
	          
	        	
	        //	WebElement firstProduct = driver.findElement(By.xpath("(//a[contains(@href,'/p/')])[1]"));
	        	
	        	WebElement firstProduct = driver.findElement(By.xpath("//a[contains(@href,'/p/')]"));
	            String productLink = firstProduct.getAttribute("href");

	            
	            // Open in new tab
	            JavascriptExecutor js = (JavascriptExecutor) driver;
	            js.executeScript("window.open(arguments[0]);", productLink);

	            
	            // Switch to new tab
	            List<String> tabs = driver.getWindowHandles().stream().toList();
	            driver.switchTo().window(tabs.get(1));
	            System.out.println("Opened first product in new tab: " + productLink);
	            


	            
	            
	            Thread.sleep(2000);
	        } catch (Exception e) {
	            System.out.println("Could not open first product.");
	        }
	    }
	 
	 
	

	

}
