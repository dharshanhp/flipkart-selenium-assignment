package FlipkartAutomation1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FlipkartHomePage {
	
	private WebDriver driver;
	
	//inti the constructor given to it 
	
	public FlipkartHomePage(WebDriver driver) {
		this.driver =driver;
		
		
	}
	
	public void closingpopup() {
		
		try {
			WebElement closeBtn = driver.findElement(By.xpath("//span[@role='button' and @class='b3wTlE' and text()='✕']"));
			
			// checking the close button are not 
			
			Thread.sleep(2000);
			
			if(closeBtn.isDisplayed()) {
				
				closeBtn.click();
				
				System.out.println("Login pop is been closed ");
				
				
			}
			
			
			
		}catch(Exception e) {
			
			e.printStackTrace();
			
			System.out.println("Login popup not displayed");
		}
	}
	
	
	// searching for the result products 
	
	public void searchProducts( String productName) {
		
		WebElement searchbox = driver.findElement(By.xpath("(//input[@name='q'  and @placeholder='Search for Products, Brands and More'])[1]"));
		
		searchbox.sendKeys(productName);
		
		// for the submission of the form it is used for search 
		
		
		
		searchbox.submit();
		
		// for the clicking actions it is given as 
		
	//	WebElement clicking = driver.findElement(By.xpath("//button[contains(@title,'Search for Products, Brands and More') and @type='button']"));
		
	//	clicking.click();
		
// searching the product action it is given as 
		
		System.out.println("Searched for: " + productName);
		
		
		
		

		
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
