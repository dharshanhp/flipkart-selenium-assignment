package FlipkartAutomation1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProductPage {
	
	private WebDriver driver;
	
	public ProductPage(WebDriver driver) {
		this.driver =driver;
		
		
	}
	
	//Check "Available offers" present are not section and print the number of the offres given 
	
	
	public void checkAvailableOffers() {
		
		try {
			
			List<WebElement> offers = driver.findElements(By.xpath("//div[contains(text(),'Available offers')]/following-sibling::ul/li"));
            if (offers.size() > 0) {
                System.out.println("Number of offers: " + offers.size());
            } else {
                System.out.println("No offers found");
            }
   	
			
			
		}catch(Exception e) {
			
			System.out.println("No offers section found");
			
		}
		
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
