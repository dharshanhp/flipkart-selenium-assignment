package FlipkartAutomation1;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CartPage {
	
	private  WebDriver driver;
	
	public CartPage(WebDriver driver) {
		
		this.driver=driver;
		
	}
	
	 // Check if Add to Cart button is available and enabled
   public boolean isAddToCartAvailable() {
        try {
            WebElement addToCartBtn = driver.findElement(By.xpath("//div[contains(text(),'Add to cart')]"));
            if (addToCartBtn.isDisplayed() && addToCartBtn.isEnabled()) {
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false; // button not found
        }}
	
	
	
	
	// Click Add to Cart and go to cart page
    public void addToCartAndGoToCart() {
        try {
            WebElement addToCartBtn = driver.findElement(By.xpath("//div[contains(text(),'Add to cart')]"));
            
            
            JavascriptExecutor js = (JavascriptExecutor) driver;

			 js.executeScript("arguments[0].scrollIntoView({block:'center'})",  addToCartBtn);
			 js.executeScript("arguments[0].click()",  addToCartBtn);

            
            
            
            
         //   addToCartBtn.click();
          //  Thread.sleep(2000); // wait for cart update

            // Go to cart
         //   driver.get("https://www.flipkart.com/viewcart?otracker=cart");
            
            //clicling the cardaction
            
            
           WebElement cart = driver.findElement(By.xpath("//span[text()='Cart']"));
            cart.click();
            
            
            Thread.sleep(2000);

            // Take screenshot
        //    takeScreenshot("cart_result.png");
            
            takeScreenshot("screenshots\\cart_result.png");
          
            System.out.println("Product added to cart. Screenshot saved: cart_result.png");

        } catch (Exception e) {
            System.out.println("Error adding product to cart");
        }}
    
    
    
    
    // Take screenshot
    public void takeScreenshot(String fileName) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            File destination = new File(fileName);
            org.openqa.selenium.io.FileHandler.copy(source, destination);
        } catch (Exception e) {
            System.out.println("Screenshot failed: " + fileName);
        }
    }

    // Handle product unavailable scenario
    public void handleProductUnavailable() {
        System.out.println("Product unavailable — could not be added to cart.");
     //   takeScreenshot("result.png");
        
        takeScreenshot("screenshots\\result.png");
    }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
